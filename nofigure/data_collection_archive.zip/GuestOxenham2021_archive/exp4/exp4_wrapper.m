%{
High frequency multiple tone (HFM), Experiment 4.
%}

%% Start
% Label
label = '1';
% Change to experiment head directory
%cd('M:\Experiments\Daniel\apc_code\hfm');
cd('M:\Experiments\Daniel\apc_code\hfm');
% Add custom signal processing and utility functions to path
addpath(genpath('M:\Experiments\Daniel\apc_code\signal'));
addpath(genpath('M:\Experiments\Daniel\apc_code\func_generic'));
% Change to experiment sub directory and add to path
cd('exp4');
addpath(genpath('.'));
%% Run
% Get participant ID
participant = input_participant_id();
% Run experiment
afc_main('exp4', participant, 'n640', '0', label);
% Print results
print_results(participant);
%% Leave everything as I found it
% Remove everything added to path
rmpath(genpath('.'));
rmpath(genpath('M:\Experiments\Daniel\apc_code\signal'));
rmpath(genpath('M:\Experiments\Daniel\apc_code\func_generic'));
% Change directory back to desktop
cd('C:\Users\n640user\Desktop\');
