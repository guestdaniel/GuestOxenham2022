%{
High frequency multiple tone (HFM) pitch screen, utility script to
print out data to terminal once screen is complete.
%}

function print_results(participant)
    % Gather data
    data_dir = 'M:/Experiments/Daniel/apc_data/hfm/exp4/data/';
    data = table2array(readtable([data_dir 'exp4_' participant '_1.dat']));
    % Set failed runs to maxval
    data(data(:, 4) == 0, 3) = 14.75;
    % Subset data into low and high
    data_high = data(data(:, 1) == 1400 & data(:, 2) == 1, 3);
    data_low = data(data(:, 1) == 280 & data(:, 2) == 1, 3);
    % Exclude first run
    data_high = data_high(2:end);
    data_low = data_low(2:end);
    % Print out!
    fprintf('==========================================================\n');
    fprintf(['RESULTS FOR LISTENER ', participant, '\n']);
    fprintf(['Average Threshold @ 280 Hz:  ', num2str(10^(mean(data_low)/10)), '%%\n']);
    fprintf(['Average Threshold @ 1400 Hz: ', num2str(10^(mean(data_high)/10)), '%%\n']);
    % Ensure that data is fully collected
    if length(data) < 6
        fprintf('Screening INCOMPLETE\n');
    % Check to ensure that criteria for Exp 3 are met
    else
        % First make sure that average thresholds are below screen values
        below_screen = (mean(data_low) <= 10*log10(6)) && (mean(data_high) <= 10*log10(12));
        % Ensure that 2.5x average threshold in both conditions is less
        % than 2.5 semitones
        max_interval_low = 10^((mean(data_low) + 10*log10(2.5))/10);
        max_interval_high = 10^((mean(data_high) + 10*log10(2.5))/10);
        cutoff = 2^(2.6/12) * 100 - 100;
        below_masker = (max_interval_low < cutoff) && (max_interval_high < cutoff);
        if below_screen && below_masker
            fprintf('Listener should proceed to Experiment 3.\n');
        else
            fprintf('Listener should not proceed to Experiment 3.\n');
        end
    end
    fprintf('==========================================================\n');

