%{
High frequency multiple tone (HFM), Experiment 4.
%}

% ready_msg			displayed when ready for user response
% measure_msg		displayed when entering measurement phase
% correct_msg		displayed after correct response
% false_msg			displayed after false response
% maxvar_msg		displayed when maxvar is reached
% minvar_msg		displayed when minvar is reached
% start_msg			displayed when the experiment starts
% next_msg			displayed when the next parameter is presented
% finished_msg		displayed when the experiment is finished

msg=struct(...
    'measure_msg', 'Beginning measurement.', ...
    'correct_msg', '--- CORRECT ---', ...
    'false_msg',   '--- INCORRECT ---', ...
    'maxvar_msg',  'Maximum level reached.', ...
    'minvar_msg',  '');

msg.ready_msg = 'In which direction did the pitch move?';
msg.start_msg    = {'You have started a new run.', ...
                    'Press any key to continue.'};
msg.next_msg     = {'End of run.', ...
                    'Press "s" when ready to start the next run.'};
msg.finished_msg = {'Experiment complete.', ...
                    'Press "e" to end.'};
msg.experiment_windetail = 'Experiment: %s';
msg.measurement_windetail = 'Measurement %d of %d';
msg.measurementsleft_windetail = '%d of %d measurements left';
msg.buttonString = {'Up [1]', 'Down [2]'};
msg.startButtonString = 's (start)';
msg.endButtonString = 'e (end)';
