%{
High frequency multiple tone (HFM) audibility screen, utility script to
print out data to terminal once screen is complete.
%}

function print_results(participant)
    % Gather data
    data_dir = 'M:/Experiments/Daniel/apc_data/hfm/screen_audibility/data/';
    data = table2array(readtable([data_dir 'screen_audibility_' participant '_1.dat']));
    data_14kHz = data(data(:, 1) == 14000 & data(:, 3) ~= 0, 2);
    data_16kHz = data(data(:, 1) == 16000 & data(:, 3) ~= 0, 2);
    % Print out!
    fprintf('==========================================================\n');
    fprintf(['RESULTS FOR LISTENER ', participant, '\n']);
    fprintf(['Average Threshold @ 14 kHz: ', num2str(mean(data_14kHz)), ' dB\n']);
    fprintf(['Average Threshold @ 16 kHz: ', num2str(mean(data_16kHz)), ' dB\n']);
    if length(data) < 6
        fprintf('Screening INCOMPLETE\n');
    else
        if (mean(data_14kHz) <= 50) && (mean(data_16kHz) <= 50)
            fprintf('Screening PASSED!\n');
        else
            fprintf('Screening FAILED!\n');
        end
    end
    fprintf('==========================================================\n');

