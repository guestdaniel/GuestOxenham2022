%{
High frequency multiple tone (HFM) audibility screen.

Version: 1.1.1

Tests thresolds for high-frequency pure tones embedded in TEN noise with
level of 40 dB SPL in 1 kHz ERB. Passing requires that thresholds be
better than 45 dB SPL for both frequencies in average of two runs per F0.

Variables:
    F0    (2 levels: 14000, 16000)

Length: 
    3 runs per F0 = 6 runs total (15-20 minutes)

Changelog: 
    2.0.0  |  Updated levels to suit new experiment (HFM UROP series).
              Level of TEN noise in 1 kHz ERB was previously 40 dB SPL, now
              it's 43 dB SPL (10/14/2019).
    1.1.1  |  Added debug plots.
    1.1.0  |  Replaced findmaxlevel with find_max_level_rms wrapper. 
              [reviewed 8/23/2018]
    1.0.0  |  Original.
%}

%% AFC parameters
def=struct(...
'expname','screen_audibility', ...	% name of experiment   
'intervalnum',2,			...		% number of intervals
'ranpos',0,					...		% interval which contains the test signal: 1 = first interval ..., 0 = random interval
'rule',[1 3],				...		% [up down]-rule: [1 3] = 1-up 3-down
'steprule',-1,				...		% stepsize is changed after each upper (-1) or lower (1) reversal
'reversalnum',6,			...		% number of reversals in measurement phase
'mouse',1,					...		% enables mouse control (1), or disables mouse control (0)  
'markinterval',1,			...		% toggles visuell interval marking on (1), off(0)
'feedback',1,				...		% visuell feedback after response: 0 = no feedback, 1 = correct/false/measurement phase
'samplerate',48000,		    ...		% sampling rate in Hz
'fs',48000,                 ...     % same as above, better name tho
'intervallen',24000,		...		% length of each signal-presentation interval in samples (might be overloaded in 'expname_set')
'pauselen',24000,			...		% length of pauses between signal-presentation intervals in samples (might be overloaded in 'expname_set')
'presiglen',5000,		    ...		% length of signal leading the first presentation interval in samples (might be overloaded in 'expname_set')
'postsiglen',5000,		    ...		% length of signal following the last presentation interval in samples (might be overloaded in 'expname_set')
'result_path','M:/Experiments/Daniel/apc_data/hfm/screen_audibility/data/',	...		    % where to save results
'control_path','M:/Experiments/Daniel/apc_data/hfm/screen_audibility/control/',...		% where to save control files
'messages','autoSelect',	...		% message configuration file
'savefcn','default',		...		% function which writes results to disk
'interleaved',0,			...		% toggles block interleaving on (1), off (0)
'interleavenum',3,		    ...		% number of interleaved runs
'debug',0,					...		% set 1 for debugging (displays all changible variables during measurement)
'dither',0,					...		% 1 = enable +- 0.5 LSB uniformly distributed dither, 0 = disable dither
'backgroundsig',0,		    ...		% allows a backgroundsignal during output: 0 = no bgs, 1 = bgs is added to the other signals, 2 = bgs and the other signals are multiplied
'terminate',1,				...		% terminate execution on min/maxvar hit: 0 = warning, 1 = terminate !!not used
'endstop',6,				...     % ???
'windetail',1,              ...     % ???
'soundmexMark',0,           ...     % ???
'allowpredict',0,           ...     % ???
'bits',24,                  ...     % ???
'headphone','HD650',        ...     % Plot debug plots?
'debug_plots',0);

%% Adapted variable: interval size
def.expvarunit = 'dB SPL';          % unit of tracked variable
def.startvar = 55;                  % starting level
def.minvar = 0;                     % min level
def.maxvar = 70;                    % max level
def.varstep = [3 2 1];              % step sizes

%% Experimental parameters
def.exppar1 = [14000 16000];        % frequencies
def.exppar1unit = 'Hz';             
def.repeatnum = 3;                  % number of repeats for each cond
def.parrand = 1;                    % random presentation

%% Stimulus parameters
% Durations
def.dur_ramp = 0.02;                % dur of cosine ramp (s)
def.dur_noise_margin = 0.075;       % dur of extra noise before/after target (s)
def.len_noise_margin = ...          % len of extra noise before/after target (samp)
    def.dur_noise_margin*def.fs;    
def.dur_tone = ...                  % dur of tone --- 75 ms onset/offset (s)
    (def.intervallen-(def.len_noise_margin*2))/def.fs;
def.dur_noise = def.intervallen;    % dur of noise (samp)
% Noise
def.level_noise = 43;               % Noise level (dB SPL, in 1 kHz ERB)
