%{
High frequency multiple tone (HFM) audibility screen.
%}

function screen_audibility_user

global def;
global work;
global set;

%% Synthesize // Targets + noise
% Synthesize tones
signal_target = pure_tone(work.exppar1, 360*rand, ...
    def.dur_tone, def.fs);
% Ramp tone
signal_target = cosine_ramp(signal_target, def.dur_ramp, def.fs);
signal_target = scale_dbspl(signal_target, work.expvaract);
% Synthesize noise
noise_reference = TE_noise(def.dur_noise/def.fs*1000, 0, def.fs/2, ...
    set.level_noise_re_max, 0, def.fs);
noise_target = TE_noise(def.dur_noise/def.fs*1000, 0, def.fs/2, ...
    set.level_noise_re_max, 0, def.fs);
% Ramp noise
noise_reference = cosine_ramp(noise_reference, def.dur_ramp, def.fs);
noise_target = cosine_ramp(noise_target, def.dur_ramp, def.fs);
% Set tones in noise
diff = (length(noise_target) - length(signal_target))/2;
signal_target = [zeros(1, diff), signal_target];
signal_reference = noise_reference;
signal_target = zadd(signal_target, noise_target);

%% DEBUG: plots
if def.debug_plots
    debug_plot_spectrum(set.debug_plot_dir, ...
        signal_reference, def.fs, [num2str(work.presentationCounter) '_ref'], 'Reference');
    debug_plot_spectrum(set.debug_plot_dir, ...
        signal_target, def.fs, [num2str(work.presentationCounter) '_tar'], 'Target');
end


%% Set to work
presig = zeros(def.presiglen, 2);
postsig = zeros(def.postsiglen, 2);
pausesig = zeros(def.pauselen, 2);

work.signal = [signal_target' signal_target' signal_reference' signal_reference'];
work.presig = presig;
work.postsig = postsig;
work.pausesig = pausesig;
