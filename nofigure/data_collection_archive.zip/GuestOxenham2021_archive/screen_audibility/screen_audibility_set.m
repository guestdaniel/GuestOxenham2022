%{
High frequency multiple tone (HFM) audibility screen.
%}

function screen_audibility_set

global def
global work
global set

set.level_max = find_max_level_rms(work.userpar1, work.userpar2, def.headphone);
set.level_noise_re_max = def.level_noise - set.level_max;

if def.debug_plots
    set.debug_plot_dir = create_ds_folder('C:\Users\guest121\apc_store\hfm\screen_audibility\debug\');
end