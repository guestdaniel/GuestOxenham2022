%{
High frequency multiple tone (HFM), Experiment 1.
%}

function exp1_set

global def
global work
global set

set.level_max = find_max_level_rms(work.userpar1, work.userpar2, def.headphone);
set.level_noise_re_max = def.level_noise - set.level_max;
set.level_harmonic_nominal = def.level_harmonic_nominal;

if def.debug_plots
    set.debug_plot_dir = create_ds_folder('C:\Users\guest121\apc_store\hfm\exp1\debug\');
end

% Pre-synthesize long sample of noise
set.presynth_noise = TE_noise(1000*30, 0, def.fs/2, ...
        set.level_noise_re_max, 0, def.fs);