%{
Synthesize double masker tones for HFM (internal pilot bp).
%}

function masker = ...
    synthesize_double_masker(F0_base, F0_masker_1, F0_masker_2)

global def;
global work;
global set;

%% Choose F0, harmonics, levels, and phases // Masker 1
% Frequencies
freqs_masker = F0_masker_1:F0_masker_1:(def.fs/2);
freqs_masker = freqs_masker(freqs_masker >= def.cutoff_low_masker*F0_base & ...
    freqs_masker <= def.cutoff_high_masker*F0_base);
% Levels
levels_masker = set.level_harmonic_nominal + ...
    ((-def.level_harmonic_rove_range + ...
    (2*def.level_harmonic_rove_range)*rand(1,  length(freqs_masker))));
% Phases
phases_masker = datasample(linspace(0, 360, 1800), length(freqs_masker), ...
    'Replace', true);

%% Synthesize maskers // Masker 1
masker = complex_tone(freqs_masker, ...
    levels_masker, phases_masker, def.dur_tone, def.fs);
% Ramp maskers
masker_1 = cosine_ramp(masker, def.dur_ramp, def.fs);

%% Choose F0, harmonics, levels, and phases // Masker 2
% Frequencies
freqs_masker = F0_masker_2:F0_masker_2:(def.fs/2);
freqs_masker = freqs_masker(freqs_masker >= def.cutoff_low_masker*F0_base & ...
    freqs_masker <= def.cutoff_high_masker*F0_base);
% Levels
levels_masker = set.level_harmonic_nominal + ...
    ((-def.level_harmonic_rove_range + ...
    (2*def.level_harmonic_rove_range)*rand(1,  length(freqs_masker))));
% Phases
phases_masker = datasample(linspace(0, 360, 1800), length(freqs_masker), ...
    'Replace', true);

%% Synthesize maskers // Masker 1
masker = complex_tone(freqs_masker, ...
    levels_masker, phases_masker, def.dur_tone, def.fs);
% Ramp maskers
masker_2 = cosine_ramp(masker, def.dur_ramp, def.fs);

%% Sum maskers
masker = masker_1 + masker_2;