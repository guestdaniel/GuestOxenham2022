%{
Get participant ID.
%}

function participant = get_pid()
    expression = '[A-z]{1}\d{2}';
    participant = input('Please input participant ID: ', 's');
    while (isempty(regexp(participant, expression, 'ONCE')))
        participant = input('Participant IDs must be in the form [a-z][1-9][1-9]. Please input participant ID again: ', 's');
    end