%{
Synthesize target tones for HFM, Experiment 1.
%}

function [signal_reference, signal_target] = ...
    synthesize_signals(F0_reference, F0_target)

global def;
global work;
global set;

%% Target
% Harmonics
freqs_target = F0_target:F0_target:(def.fs/2);
freqs_target = freqs_target(freqs_target >= def.cutoff_low*F0_target & ...
    freqs_target <= def.cutoff_high*F0_target);
% Levels 
levels_target = set.level_harmonic_nominal + ((-def.level_harmonic_rove_range + ...
    (2*def.level_harmonic_rove_range)*rand(1, length(freqs_target))));
% Phases
phases_target = 360*rand(1, length(freqs_target));
% Synthesize
signal_target = complex_tone(freqs_target, ...
    levels_target, phases_target, def.dur_tone, def.fs);
% Ramp
signal_target = cosine_ramp(signal_target, def.dur_ramp, def.fs);

%% References
references = zeros(def.n_precursor, def.dur_tone*def.fs);
for ii=1:def.n_precursor
    % Harmonics
    freqs_reference = F0_reference:F0_reference:(def.fs/2);
    freqs_reference = freqs_reference(freqs_reference >= def.cutoff_low*F0_reference & ...
        freqs_reference <= def.cutoff_high*F0_reference);
    % Levels
    levels_reference = set.level_harmonic_nominal + ((-def.level_harmonic_rove_range + ...
        (2*def.level_harmonic_rove_range)*rand(1, length(freqs_reference))));
    % Phases
    phases_reference = 360*rand(1, length(freqs_reference));
    % Synthesize
    signal_reference = complex_tone(freqs_reference, ...
        levels_reference, phases_reference, def.dur_tone, def.fs);
    % Ramp
    signal_reference = cosine_ramp(signal_reference, def.dur_ramp, def.fs);
    references(ii, :) = signal_reference;
end

%% Make references into single signal
signal_reference = [];
diff = (2*def.intervallen - def.dur_tone*def.fs)/2;
for ii=1:def.n_precursor
    temp = [zeros(1, diff) references(1, :) zeros(1, diff)];
    signal_reference = [signal_reference temp zeros(1, def.len_skip)];
end
