%{
Synthesize TEN noise for HFM (internal pilot bp).
%}

function noise = synthesize_noise()

    global def;
    global work;
    global set;

    %% Target
    % Synthesize
    noise = select_segment(set.presynth_noise, def.len_noise);
    % Ramp noise
    noise = cosine_ramp(noise, def.dur_ramp, def.fs);