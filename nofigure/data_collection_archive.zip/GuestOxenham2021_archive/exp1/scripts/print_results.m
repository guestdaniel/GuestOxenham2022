%{
High frequency multiple tone (HFM) pitch screen, utility script to
print out data to terminal once screen is complete.
%}

function print_results(participant)
    % Gather data
    data_dir = 'M:/Experiments/Daniel/apc_data/hfm/exp1/data/';
    data = table2array(readtable([data_dir 'exp1_' participant '_1.dat']));
    data_high = data(data(:, 1) == 1400 & data(:, 2) == 1 & data(:, 4) ~= 0, 3);
    data_low = data(data(:, 1) == 280 & data(:, 2) == 1 & data(:, 4) ~= 0, 3);
    % Print out!
    fprintf('==========================================================\n');
    fprintf(['RESULTS FOR LISTENER ', participant, '\n']);
    fprintf(['Average Threshold @ 280 Hz:  ', num2str(10^(mean(data_low)/10)), '%%\n']);
    fprintf(['Average Threshold @ 1400 Hz: ', num2str(10^(mean(data_high)/10)), '%%\n']);
    if length(data) < 6
        fprintf('Screening INCOMPLETE\n');
    else
        if (mean(data_low) <= 10*log10(6)) && (mean(data_high) <= 10*log10(12))
            fprintf('Listener should proceed to Experiment 2.\n');
        else
            fprintf('Listener should not proceed to Experiment 2.\n');
        end
    end
    fprintf('==========================================================\n');

