%{
Synthesize masker tones for HFM (internal pilot bp).
%}

function masker = synthesize_single_masker(F0_base, F0_masker)

global def;
global work;
global set;

%% Choose F0, harmonics, levels, and phases
% Frequencies
freqs_masker = F0_masker:F0_masker:(def.fs/2);
freqs_masker = freqs_masker(freqs_masker >= def.cutoff_low_masker*F0_base & ...
    freqs_masker <= def.cutoff_high_masker*F0_base);
% Levels
levels_masker = set.level_harmonic_nominal + ...
    ((-def.level_harmonic_rove_range + ...
    (2*def.level_harmonic_rove_range)*rand(1,  length(freqs_masker))));
% Phases
phases_masker = 360*rand(1, length(freqs_masker));
%% Synthesize maskers
masker = complex_tone(freqs_masker, ...
    levels_masker, phases_masker, def.dur_tone, def.fs);
% Ramp maskers
masker = cosine_ramp(masker, def.dur_ramp, def.fs);