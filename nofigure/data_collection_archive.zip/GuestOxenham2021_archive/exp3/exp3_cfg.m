%{
High frequency multiple tone (HFM), Experiment 3.

Version: 1.1.1

Measures the SNR required for 79% correct for HCT in TEN noise with a masker HCT. 
A precursor composed of 3 isolated copies of the target is presented first
and then target + masker mixture is presented. The target either shifted up
or down, and listeners discriminate the direction of the F0 change.
Target HCTs are composed of bandpass-filtered harmonics of nominal 
F0s of either 280 or 1400 Hz. Bandpass filters are centered on the
nominal F0. Levels and phases of individual harmonics are 
roved in both target and masker across intervals and trials. Masker HCTs 
are filtered into similar but broader regions and similarly synthesized.
The masker nominal harmonic level is varied adaptively.

Variables:
    Nominal F0 (2 levels: 280, 1400)
    Interval size (2 levels: 1.5x 2.5x)

Length:
    7 runs per condition = 28 runs total (1.5-2 hrs)

Changelog:
    1.0.0  |  Original
%}

%% AFC parameters
def=struct(...
'expname','exp3',           ...     % name of experiment   
'intervalnum',2,			...		% number of intervals
'ranpos',2,					...		% interval which contains the test signal: 1 = first interval ..., 0 = random interval
'rule',[1 3],				...		% [up down]-rule: [1 2] = 1-up 3-down
'steprule',-1,				...		% stepsize is changed after each upper (-1) or lower (1) reversal
'reversalnum',6,			...		% number of reversals in measurement phase
'mouse',1,					...		% enables mouse control (1), or disables mouse control (0)  
'markinterval',0,			...		% toggles visuell interval marking on (1), off(0)
'feedback',1,				...		% visuell feedback after response: 0 = no feedback, 1 = correct/false/measurement phase
'samplerate',48000,		    ...		% sampling rate in Hz
'fs',48000,                 ...     % same as above, better name tho
'result_path','M:/Experiments/Daniel/apc_data/hfm/exp3/data/',	...		% where to save results
'control_path','M:/Experiments/Daniel/apc_data/hfm/exp3/control/',...		% where to save control files
'messages','autoSelect',	...		% message configuration file
'savefcn','default',		...		% function which writes results to disk
'interleaved',0,			...		% toggles block interleaving on (1), off (0)
'interleavenum',3,		    ...		% number of interleaved runs
'debug',0,					...		% set 1 for debugging (displays all changible variables during measurement)
'dither',0,					...		% 1 = enable +- 0.5 LSB uniformly distributed dither, 0 = disable dither
'backgroundsig',1,		    ...		% allows a backgroundsignal during output: 0 = no bgs, 1 = bgs is added to the other signals, 2 = bgs and the other signals are multiplied
'terminate',1,				...		% terminate execution on min/maxvar hit: 0 = warning, 1 = terminate !!not used
'endstop',6,				...     % ???
'windetail',1,              ...     % ???
'soundmexMark',0,           ...     % ???
'allowpredict',0,           ...     % ???
'bits',24,                  ...     % ???
'headphone','HD650',        ...     % Plot debug plots?
'debug_plots',0);

%% Adapted variable: interval size
def.expvarunit = '-(dB above target)'; % unit of tracked variable
def.startvar = 0;                   % starting level
def.minvar = -100;                  % min level
def.maxvar = 20;                    % max level
def.varstep = [3 2 1];              % step sizes

%% Experimental parameters
def.exppar1 = [280 1400];           % nominal F0s
def.exppar1unit = 'Hz';             
def.exppar2 = [1.5 2.5];            % interval size, re: ISO F0DLs in Exp 1
def.exppar2unit = '#';              
def.repeatnum = 7;                  % number of repeats for each cond
def.parrand = 1;                    % random presentation

%% Stimulus parameters
% ///// Overall /////
def.n_precursor = 3;
% ///// Durations /////
def.dur_ramp = 0.02;                % dur of cosine ramp (s)
def.dur_noise_margin = 0.075;       % dur of extra noise before/after target (s)
def.dur_tone = 0.350;               % dur of tone (s)
def.dur_skip = 0.050;               % duration of gap between HCTs (s)
% ///// Lengths /////
def.len_skip = def.dur_skip*def.fs; % len between precursors/targets (samp)
def.len_noise_margin = ...          % len of extra noise before/after target (samp)
    def.dur_noise_margin*def.fs;    
def.intervallen = ...               % len of each AFC presentation interval (samp)
    (def.dur_tone*def.fs)/2; 
def.pauselen = 0;			        % NO PAUSE
def.presiglen = ...                 % len of precursor (samp) 
    def.n_precursor*def.dur_tone*def.fs + ...   
    def.n_precursor*def.len_skip + def.len_noise_margin;
def.postsiglen = ...                % len of postcursor (samp)
    def.len_noise_margin;
def.len_stimulus = def.dur_tone*def.fs*(def.n_precursor+1) + ...
    def.len_skip*def.n_precursor;   % len of entire stimulus (samp)
def.len_noise = def.len_stimulus ...% len of noise (samp)
    + 2*def.len_noise_margin; 
% ///// Levels /////
def.level_harmonic_nominal = 50;    % nominal level for each harmonic (dB SPL)
def.level_harmonic_rove_range = 3;  % level rove range (+/- dB SPL)
def.level_noise = 40;               % noise level (dB SPL, in 1 kHz band)
% ///// Filter /////
% Around F0 for signal HCTs, around geometric center F0 for masker HCTs
def.cutoff_low = 5.50;              % low cutoff of bandpass (mult. of nominal F0)
def.cutoff_high = 10.50;            % high cutoff of bandpass (mult. of nominal F0)
def.filter_order = 3;               % 1/2 of bandpass filter order
def.cutoff_low_masker = 4;          % low cutoff of masker bandpass (mult. of nominal F0)
def.cutoff_high_masker = 12;        % low cutoff of masker bandpass (mult. of nominal F0)
% ///// F0s /////
def.rove_range = 10;                % F0 rove range (+/- percent)
def.double_masker_interval = 5.25;     % min between target and dbl masker F0 (ST)
def.double_masker_rove_amt = 2;     % double masker F0 rove range (ST)
