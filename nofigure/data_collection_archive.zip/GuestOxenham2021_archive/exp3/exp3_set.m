%{
High frequency multiple tone (HFM), Experiment 3.
%}

function exp3_set

global def
global work
global set

%% Adjust interval sizes for each participant based on their Exp 4 data.
% Extract participant's ISO Exp4 data and calculate means from all runs
% except first run at each nominal F0.
exp4_data_dir = 'M:/Experiments/Daniel/apc_data/hfm/exp4/data/';
exp4_data = table2array(readtable([exp4_data_dir 'exp4_' work.vpname '_1.dat']));
data_low = exp4_data((exp4_data(:, 1) == 280 & exp4_data(:, 2) == 1), 3);
data_low = data_low(2:end); % throw away first run
data_high = exp4_data((exp4_data(:, 1) == 1400 & exp4_data(:, 2) == 1), 3);
data_high = data_high(2:end); % throw away first run
% Set intervals rule:
    % 1) Multiply thresholds from ISO condition by constant
    % 2) If they're above 2.5 ST, set them to 2.5 ST
set.interval_280 = mean(data_low) + 10*log10(work.exppar2);
set.interval_1400 = mean(data_high) + 10*log10(work.exppar2);
if 12*log2(10^(set.interval_280/10)/100 + 1) > 2.5
    set.interval_280 = 10*log10(100*2^(2.5/12) - 100);
end
if 12*log2(10^(set.interval_1400/10)/100 + 1) > 2.5
    set.interval_1400 = 10*log10(100*2^(2.5/12) - 100);
end
% Check for errors
assert(~isnan(set.interval_280), 'ERROR: Interval size in NaN');
assert(~isnan(set.interval_1400), 'ERROR: Interval size in NaN');
% Print results
fprintf('==============================================================\n');
fprintf('INTERVALS\n');
fprintf(['Interval size (280 Hz): ' num2str(set.interval_280) ' 10*log10(%%)' '\n']);
fprintf(['Interval size (280 Hz): ' num2str(10^(set.interval_280/10)) ' %%' '\n']);
fprintf(['Interval size (1400 Hz): ' num2str(set.interval_1400) ' 10*log10(%%)' '\n']);
fprintf(['Interval size (1400 Hz): ' num2str(10^(set.interval_1400/10)) ' %%' '\n']);
fprintf('==============================================================\n');

%% Set levels and set up noise
set.level_max = find_max_level_rms(work.userpar1, work.userpar2, def.headphone);
set.level_noise_re_max = def.level_noise - set.level_max;
set.level_harmonic_nominal = def.level_harmonic_nominal;

if def.debug_plots
    set.debug_plot_dir = create_ds_folder('C:\Users\guest121\apc_store\hfm\exp3\debug\');
end

% Pre-synthesize long sample of noise
set.presynth_noise = TE_noise(1000*30, 0, def.fs/2, ...
        set.level_noise_re_max, 0, def.fs);