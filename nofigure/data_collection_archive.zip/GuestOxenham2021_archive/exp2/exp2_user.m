%{
High frequency multiple tone (HFM), Experiment 2.
%}

function exp2_user

global def;
global work;
global set;

%% Synthesize target
% Choose F0s
switch work.exppar1
    case 280
        delta_F0 = 10^(set.interval_280/10); % transform 10log10(%) -> %
        fprintf(['Interval size (280 Hz): ' num2str(delta_F0) ' %%' '\n']);
    case 1400
        delta_F0 = 10^(set.interval_1400/10); % transform 10log10(%) -> %
        fprintf(['Interval size (1400 Hz): ' num2str(delta_F0) ' %%' '\n']);
end
F0_base = work.exppar1 + work.exppar1 * ...
    ((-def.rove_range + (2*def.rove_range)*rand)/100);
% Randomly select either upward or downward pitch shift
if randi([0 1]) == 0
    F0_reference = F0_base/sqrt(1 + delta_F0/100);
    F0_target = F0_base*sqrt(1 + delta_F0/100);
    work.correctResponse = 1; % UP
else
    F0_reference = F0_base*sqrt(1 + delta_F0/100);
    F0_target = F0_base/sqrt(1 + delta_F0/100);
    work.correctResponse = 2; % DOWN
end
% Synthesize
[signal_reference, signal_target] = ...
    synthesize_signals(F0_reference, F0_target);

%% Synthesize noise
noise = synthesize_noise();

%% If relevant, synthesize and add maskers
switch work.exppar2
    case 3 % Double masker
        % Choose F0s
        interval_1 = def.double_masker_interval + (def.double_masker_rove_amt)*rand;
        interval_2 = def.double_masker_interval + (def.double_masker_rove_amt)*rand;
        F0_masker_1 = F0_target*2^(-interval_1/12); % Below target
        F0_masker_2 = F0_target*2^(interval_2/12);  % Above target
        % Synthesize
        masker = ...
            synthesize_double_masker(F0_base, F0_masker_1, F0_masker_2);
        % Mix targets and maskers
        signal_target = signal_target + masker;
end

%% Set tones in noise
signal_reference = [zeros(1, def.len_noise_margin) signal_reference];
work.bgsig = [noise' noise'];

%% DEBUG: plots
if def.debug_plots
    debug_plot_spectrum(set.debug_plot_dir, ...
        signal_reference, def.fs, [num2str(work.presentationCounter) '_ref'], 'Reference');
    debug_plot_spectrum(set.debug_plot_dir, ...
        signal_target, def.fs, [num2str(work.presentationCounter) '_tar'], 'Target');
    debug_plot_spectrum(set.debug_plot_dir, ...
        noise, def.fs, [num2str(work.presentationCounter) '_noise'], 'Noise');
end

%% AFC stuff
% Post/pause sig - unimportant
postsig = zeros(def.postsiglen, 2);
pausesig = zeros(def.pauselen, 2);
% Presig - contains precursors/reference
presig = [signal_reference' signal_reference'];
% signal - contains target, split across the two intervals (hack so we get
% two buttons in interface w/o digging into AFC)... it should go in
% backward because "target" is forced to always be interval 2, but AFC needs
% "target" to be the first thing in the array
signal_part_1 = signal_target(1:(length(signal_target)/2));
signal_part_2 = signal_target(((length(signal_target)/2)+1):end);
work.signal = [signal_part_2' signal_part_2' signal_part_1' signal_part_1'];
work.presig = presig;
work.postsig = postsig;
work.pausesig = pausesig;
