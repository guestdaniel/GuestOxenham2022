%{
High frequency multiple tone (HFM), Experiment 2.
%}

%% Start
% Label
label = '1';
% Change to experiment head directory
cd('M:\Experiments\Daniel\apc_code\hfm');
% Add custom signal processing and utility functions to path
addpath(genpath('M:\Experiments\Daniel\apc_code\signal'));
addpath(genpath('M:\Experiments\Daniel\apc_code\func_generic'));
% Change to experiment sub directory and add to path
cd('exp2');
addpath(genpath('.'));
%% Run
% Get participant ID
participant = input_participant_id();
% Run experiment
afc_main('exp2', participant, 'n640', '0', label);
%% Leave everything as I found it
% Remove everything added to path
rmpath(genpath('.'));
rmpath(genpath('M:\Experiments\Daniel\apc_code\signal'));
rmpath(genpath('M:\Experiments\Daniel\apc_code\func_generic'));
% Change directory back to desktop
cd('C:\Users\n640user\Desktop\');
