%{
High frequency multiple tone (HFM), Experiment 2.

Version: 1.1.1

Measures proportion correct for F0 discrimination at fixed interval for 
HCTs in TEN noise either with two masker HCTs flanking the target.
Precursor composed of three copies of isolated target is presented first 
and then target + masker mixture is presented, with the target either 
shifted up or down. Target HCTs are composed of bandpass filtered harmonics
of nominal F0s of either 280 or 1400 Hz. Levels and phases of individual 
harmonics are roved in both target and masker across intervals. Masker HCTs
are filtered into similar but slightly broader regions and similarly synthesized.

The interval size for a given listener for each nominal F0 is fixed at 1
times their average F0DL in the corresponding ISO condition in Experiment
1, within bounds from 1.5 ST to 2.5 ST. When calculating this value, the
first run in each condition is thrown away.

Variables:
    Nominal F0 (2 levels: 280, 1400)
    Masker     (3 levels: double [DBL])

Length:
    4 runs per condition = 8 runs total (50-60 minutes)

Changelog:
    1.1.1  |  Added debug plots.
    1.1.0  |  Remove deprecated code and updated level function.s
              [Reviewed 8/23/2018]
    1.0.0  |  Original
%}

%% AFC parameters
def=struct(...
'expname','exp2', ... % name of experiment   
'measurementProcedure','constantStimuli', ... % procedure
'intervalnum',2,			...		% number of intervals
'ranpos',2,					...		% interval which contains the test signal: 1 = first interval ..., 0 = random interval
'mouse',1,					...		% enables mouse control (1), or disables mouse control (0)  
'markinterval',0,			...		% toggles visuell interval marking on (1), off(0)
'feedback',1,				...		% visuell feedback after response: 0 = no feedback, 1 = correct/false/measurement phase
'samplerate',48000,		    ...		% sampling rate in Hz
'fs',48000,                 ...     % same as above, better name tho
'result_path','M:/Experiments/Daniel/apc_data/hfm/exp2/data/',	...		% where to save results
'control_path','M:/Experiments/Daniel/apc_data/hfm/exp2/control/',...		% where to save control files
'messages','autoSelect',	...		% message configuration file
'savefcn','default',		...		% function which writes results to disk
'interleaved',0,			...		% toggles block interleaving on (1), off (0)
'interleavenum',3,		    ...		% number of interleaved runs
'debug',0,					...		% set 1 for debugging (displays all changible variables during measurement)
'dither',0,					...		% 1 = enable +- 0.5 LSB uniformly distributed dither, 0 = disable dither
'backgroundsig',1,		    ...		% allows a backgroundsignal during output: 0 = no bgs, 1 = bgs is added to the other signals, 2 = bgs and the other signals are multiplied
'terminate',1,				...		% terminate execution on min/maxvar hit: 0 = warning, 1 = terminate !!not used
'endstop',6,				...     % ???
'windetail',1,              ...     % ???
'soundmexMark',0,           ...     % ???
'allowpredict',0,           ...     % ???
'headphone','HD650',        ...     % Plot debug plots?
'debug_plots',0);

% expvar for within-block parameters
%% Experimental variable: interval size
def.expvarunit = 'n/a';      % unit of interval
def.expvar = [0];           % size of interval

%% Experimental parameters
def.exppar1 = [280 1400];           % nominal F0s
def.exppar1unit = 'Hz';             
def.exppar2 = [3];                  % masker type
def.exppar2unit = '#';              
def.repeatnum = 4;                  % number of repeats for each cond
def.parrand = 1;                    % random presentation
def.expvarnum = 100;                % number of trials per block
def.expvarord = 0;                  % order of presentation?

%% Stimulus parameters
% ///// Overall /////
def.n_precursor = 3;
% ///// Durations /////
def.dur_ramp = 0.02;                % dur of cosine ramp (s)
def.dur_noise_margin = 0.075;       % dur of extra noise before/after target (s)
def.dur_tone = 0.350;               % dur of tone (s)
def.dur_skip = 0.050;               % duration of gap between HCTs (s)
% ///// Lengths /////
def.len_skip = def.dur_skip*def.fs; % len between precursors/targets (samp)
def.len_noise_margin = ...          % len of extra noise before/after target (samp)
    def.dur_noise_margin*def.fs;    
def.intervallen = ...               % len of each AFC presentation interval (samp)
    (def.dur_tone*def.fs)/2; 
def.pauselen = 0;			        % NO PAUSE
def.presiglen = ...                 % len of precursor (samp) 
    def.n_precursor*def.dur_tone*def.fs + ...   
    def.n_precursor*def.len_skip + def.len_noise_margin;
def.postsiglen = ...                % len of postcursor (samp)
    def.len_noise_margin;
def.len_stimulus = def.dur_tone*def.fs*(def.n_precursor+1) + ...
    def.len_skip*def.n_precursor;   % len of entire stimulus (samp)
def.len_noise = def.len_stimulus ...% len of noise (samp)
    + 2*def.len_noise_margin; 
% ///// Levels /////
def.level_harmonic_nominal = 50;    % nominal level for each harmonic (dB SPL)
def.level_harmonic_rove_range = 3;  % level rove range (+/- dB SPL)
def.level_noise = 40;               % noise level (dB SPL, in 1 kHz band)
% ///// Filter /////
% Around F0 for signal HCTs, around geometric center F0 for masker HCTs
def.cutoff_low = 5.50;              % low cutoff of bandpass (mult. of F0)
def.cutoff_high = 10.50;            % high cutoff of bandpass (mult. of F0)
def.cutoff_low_masker = 4.50;       % low cutoff of masker bandpass (mult. of F0)
def.cutoff_high_masker = 11.50;     % low cutoff of masker bandpass (mult. of F0)
% ///// F0s /////
def.rove_range = 10;                % F0 rove range (+/- percent)
def.double_masker_interval = 5.25;     % min between target and dbl masker F0 (ST)
def.double_masker_rove_amt = 2;     % double masker F0 rove range (ST)
