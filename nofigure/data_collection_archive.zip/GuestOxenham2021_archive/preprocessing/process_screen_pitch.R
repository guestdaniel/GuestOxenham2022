####################
# Process pitch screening data
# HFM External Pilot
####################

# Define data directories data and create as necessary
raw_data_dir = "~/apc_data/hfm/screen_pitch/"
clean_data_dir = "~/apc_store/hfm/screen_pitch/data/"
dir.create(paste0(clean_data_dir, Sys.Date()), recursive=TRUE)
# Collect data into data frame
data_files = list.files(raw_data_dir)
data_files = data_files[grepl(".dat", data_files)]
subj_ids = regmatches(data_files, regexpr("[A-z]{1}\\d{2,3}", data_files))
if (length(data_files) != length(subj_ids)) {
		stop("EXECUTION FAILED. More data files than subjects!")
}
dat = data.frame()
for (ii in 1:length(data_files)) {
		temp = read.table(paste0(raw_data_dir, data_files[ii]), sep="", header=T, row.names=NULL, fill=TRUE)
		#temp$attempt = as.numeric(substr(strsplit(data_files[ii], "_")[[1]][4], 1, 1)) # WARNING: FRAGILE
		#colnames(temp) = c("F0", "threshold", "sd", "attempt")
		colnames(temp) = c("F0", "threshold", "sd")
		temp$subj = subj_ids[ii]
		temp$F0 = factor(as.numeric(temp$F0))
		dat = rbind(dat, temp)
}
dat[dat$subj == 'z99' | dat$subj == 'z98', 'subj'] = 'x00'  # z99/z98 are my subject ids, we make them 'x00'
dat = dat[substr(dat$subj, 1, 1) == 'x', ]  # get rid of any non-x subject ids
dat$subj = factor(dat$subj)
# Save clean version
save(file=paste0(clean_data_dir, Sys.Date(), "/", "clean_data.RData"), dat)
write.csv(dat, file=paste0(clean_data_dir, Sys.Date(), "/", "clean_data.csv"))
