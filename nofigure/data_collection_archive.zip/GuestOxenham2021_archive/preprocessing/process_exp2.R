####################
# Process Experiment 2 Data 
# HFM  
####################

# Define data directories data and create as necessary
raw_data_dir = "~/apc_data/hfm/exp2/"
clean_data_dir = "~/apc_store/hfm/exp2/data/"
dir.create(paste0(clean_data_dir, Sys.Date()), recursive=TRUE)
# Collect data into data frame
data_files = list.files(raw_data_dir)
data_files = data_files[grepl(".dat", data_files)]
subj_ids = regmatches(data_files, regexpr("[A-z]{1}\\d{2}", data_files))
if (length(data_files) != length(subj_ids)) {
		stop("EXECUTION FAILED. More data files than subjects!")
}
dat = data.frame()
for (ii in 1:length(data_files)) {
		temp = read.table(paste0(raw_data_dir, data_files[ii]), sep="", header=F, row.names=NULL, fill=TRUE, skip=1)
		colnames(temp) = c("block", "track", "F0", "masker", "n/a", "n", "n_corr")
		temp$subj = subj_ids[ii]
		temp$F0 = factor(as.numeric(temp$F0))
		dat = rbind(dat, temp)
}
dat[dat$subj == 'z99' | dat$subj == 'z98', 'subj'] = 'x00'  # z99/z98 are my subject ids, we make them 'x00'
dat = dat[substr(dat$subj, 1, 1) == 'x', ]  # get rid of any non-x subject ids
dat$subj = factor(dat$subj)
dat$masker = factor(dat$masker)
levels(dat$masker) = c("DBL")
# Save clean version
save(file=paste0(clean_data_dir, Sys.Date(), "/", "clean_data.RData"), dat)
write.csv(dat, file=paste0(clean_data_dir, Sys.Date(), "/", "clean_data.csv"))
