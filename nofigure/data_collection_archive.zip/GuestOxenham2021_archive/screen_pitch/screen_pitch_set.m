%{
High frequency multiple tone (HFM) pitch screen.
%}

function screen_pitch_set

global def
global work
global set

set.level_max = find_max_level_rms(work.userpar1, work.userpar2, def.headphone);
set.level_harmonic_nominal = def.level_harmonic_nominal;

if def.debug_plots
    set.debug_plot_dir = create_ds_folder('C:\Users\guest121\apc_store\hfm\screen_pitch\debug\');
end