%{
High frequency multiple tone (HFM) pitch screen.

Version: 1.2.0

Measures F0DLs for HCTs. Precursor composed of three reference repetitions 
is presented first, then target is presented. The target has either a
 higher or lower F0 than the reference and the listener chooses direction of
shift. Target HCTs are composed of bandpass filtered harmonics of nominal 
F0s of either 280 or 1400 Hz. Phases are randomized, but no level 
randomization takes place and no masking noise is present.

Variables:
    Nominal F0 (2 levels: 280, 1400)

Length:
    3 runs per F0 = 6 runs (15-20 minutes)

Changelog:
    2.0.0  |  Updated levels to suit new experiment (HFM UROP series).
              Level per-component was 50 dB SPL, now it's 55 dB SPL
              (10/14/2019)
    1.2.0  |  Changed synthesis strategy to match Exp 4 synthesis strategy
              to ensure that listeners are exposed to bandpass filter
              before participating in experiment.
    1.1.1  |  Added debug plots.
    1.1.0  |  Cleaned up deprecated/commented code in various functions.
              [Reviewed 8/23/2018]
    1.0.0  |  Original
%}

%% AFC parameters
def=struct(...
'expname','screen_pitch', ... % name of experiment   
'intervalnum',2,			...		% number of intervals
'ranpos',2,					...		% interval which contains the test signal: 1 = first interval ..., 0 = random interval
'rule',[1 3],				...		% [up down]-rule: [1 3] = 1-up 3-down
'steprule',-1,				...		% stepsize is changed after each upper (-1) or lower (1) reversal
'reversalnum',6,			...		% number of reversals in measurement phase
'mouse',1,					...		% enables mouse control (1), or disables mouse control (0)  
'markinterval',0,			...		% toggles visuell interval marking on (1), off(0)
'feedback',1,				...		% visuell feedback after response: 0 = no feedback, 1 = correct/false/measurement phase
'samplerate',48000,		    ...		% sampling rate in Hz
'fs',48000,                 ...     % same as above, better name tho
'result_path','M:/Experiments/Daniel/apc_data/hfm/screen_pitch/data/',	...		% where to save results
'control_path','M:/Experiments/Daniel/apc_data/hfm/screen_pitch/control/',...		% where to save control files
'messages','autoSelect',	...		% message configuration file
'savefcn','default',		...		% function which writes results to disk
'interleaved',0,			...		% toggles block interleaving on (1), off (0)
'interleavenum',3,		    ...		% number of interleaved runs
'debug',0,					...		% set 1 for debugging (displays all changible variables during measurement)
'dither',0,					...		% 1 = enable +- 0.5 LSB uniformly distributed dither, 0 = disable dither
'backgroundsig',0,		    ...		% allows a backgroundsignal during output: 0 = no bgs, 1 = bgs is added to the other signals, 2 = bgs and the other signals are multiplied
'terminate',1,				...		% terminate execution on min/maxvar hit: 0 = warning, 1 = terminate !!not used
'endstop',6,				...     % ???
'windetail',1,              ...     % ???
'soundmexMark',0,           ...     % ???
'allowpredict',0,           ...     % ???
'bits',24,                  ...     % ???
'headphone','HD650',        ...     % Plot debug plots?
'debug_plots',0);

%% Adapted variable: interval size
def.expvarunit = '10log10(%)';      % unit of tracked interval
def.startvar = 10;                  % starting interval
def.minvar = -30;                   % min interval, 10e-03 %
def.maxvar = 14.75;                 % max interval, approx. 30%
def.varstep = [3.0 1.5 0.75];       % step sizes

%% Experimental parameters
def.exppar1 = [280 1400];           % nominal F0s
def.exppar1unit = 'Hz';             
def.repeatnum = 3;                  % number of repeats for each cond
def.parrand = 1;                    % random presentation

%% Stimulus parameters
% ///// Overall /////
def.n_precursor = 3;
% ///// Durations /////
def.dur_ramp = 0.02;                % dur of cosine ramp (s)
def.dur_noise_margin = 0.075;       % dur of extra noise before/after target (s)
def.dur_tone = 0.350;               % dur of tone (s)
def.dur_skip = 0.050;               % duration of gap between HCTs (s)
% ///// Lengths /////
def.len_skip = def.dur_skip*def.fs; % len between precursors/targets (samp)
def.len_noise_margin = ...          % len of extra noise before/after target (samp)
    def.dur_noise_margin*def.fs;    
def.intervallen = ...               % len of each AFC presentation interval (samp)
    (def.dur_tone*def.fs)/2; 
def.pauselen = 0;			        % NO PAUSE
def.presiglen = ...                 % len of precursor (samp) 
    def.n_precursor*def.dur_tone*def.fs + ...   
    def.n_precursor*def.len_skip + def.len_noise_margin;
def.postsiglen = ...                % len of postcursor (samp)
    def.len_noise_margin;
def.len_stimulus = def.dur_tone*def.fs*(def.n_precursor+1) + ...
    def.len_skip*def.n_precursor;   % len of entire stimulus (samp)
def.len_noise = def.len_stimulus ...% len of noise (samp)
    + 2*def.len_noise_margin; 
% ///// Levels /////
def.level_harmonic_nominal = 55;    % nominal level for each harmonic (dB SPL)
% ///// Filter /////
% Around F0 for signal HCTs, around geometric center F0 for masker HCTs
def.cutoff_low = 5.50;              % low cutoff of bandpass (mult. of F0)
def.cutoff_high = 10.50;            % high cutoff of bandpass (mult. of F0)
def.filter_order = 3;               % 1/2 of bandpass filter order
% ///// F0s /////
def.rove_range = 10;                % F0 rove range (+/- percent)
def.level_harmonic_rove_range = 0;